﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Resources;
using Graphics;
using Utils;
using System.Diagnostics;
using static Resources.StaticSpriteFactory;
using System;


namespace UI
{
    public class UIComponent
    {

        public enum UIComponentTypes
        {
            //COMMON
            //FRAME
            FRAME, FRAMEPART,
            //TEXT
            TEXT, TEXT_FRAME, TEXT_AREA,
            //ICON
            ICON,
            //BUTTON
            BUTTON, BUTTON_FRAME, BUTTON_TEXT, BUTTON_TEXT_FRAME, BUTTON_ICON, BUTTON_ICON_FRAME,
            //BARS
            STAT_BAR,
            //MISC

            //MENU
            MENU_INGAME, MENU_INGAME_INVENTORY, MENU_INGAME_SKILLS, MENU_INGAME_QUESTBOOK, MENU_INGAME_STATISTICS,
            //WINDOWS
            WARNING_WINDOW,
            //HUD
            HUD, CURSOR, PLAYER_INDICATORS,
            //INVENTORY
            INVENTORY, INVENTORY_SLOT, INVENTORY_SLOTBOARD,
            INVENTORY_TO_EQUIPMENT, INVENTORY_TO_INVENTORY,
            INVENTORY_SORTING_PANEL, INVENTORY_SORTING_PANEL_OPTION,
            INVENTORY_PAGER,
            //DIALOGUE
            DIALOGUE, DIALOGUE_PANEL, DIALOGUE_OPTIONS_PANEL,
            //EQUIPMENT
            EQUIPMENT, EQUIPMENT_SLOT,
        }

        public AnimationSet aManager;
        public StaticSprites sprite;
        public StaticSprite spriteData;

        public Vector2 Position;
        public float Rotation;
        public Vector2 Origin;
        public Vector2 Scale;
        public Color Color;

        public Vector2 adjPosition;
        public float adjRotation;
        public Vector2 adjOrigin;
        public Vector2 adjScale;

        //states
        public bool IsStickToCameraState;
        public bool IsStickToZoomState;
        public bool IsStickToCursorState;
        public bool IsAppliedHalfScreenOriginState;

        //flags
        public bool WasRefreshedFlag;

        public UIComponent[] children;

        public string Text;
        public Font Font;

        public UIComponentTypes type;

        public int Id { get; set; }

        public UIComponent(int id)
        {
            Id = id;
            Position = Vector2.Zero;
            Rotation = 0f;
            Origin = Vector2.Zero;
            Scale = new Vector2(1, 1);
            Color = Color.White;
        }

        public virtual void Update()
        {
            adjPosition = Position;
            adjRotation = Rotation;
            adjOrigin = Origin;
            adjScale = Scale;

            if (IsAppliedHalfScreenOriginState)
            {
                adjPosition -= new Vector2(Graphics.Graphics.Screen.Width / 2, Graphics.Graphics.Screen.Height / 2);
            }

            float zoomFactor = 1f;
            if (IsStickToZoomState)
            {
                float currentZoom = (float)Graphics.Graphics.Camera.Z;
                float baseZoom = (float)Graphics.Graphics.Camera.GetZFromHeight(Graphics.Graphics.Screen.Height);
                zoomFactor = currentZoom / baseZoom;
                adjScale *= zoomFactor;
            }

            if (IsStickToCursorState)
            {
                Vector2 mouseWorldPos = Inputs.Inputs.mouse.GetMouseWorldPosition();
                adjPosition = mouseWorldPos;
            }
            else if (IsStickToCameraState)
            {
                adjPosition += Graphics.Graphics.Camera.Position;
                if (IsStickToZoomState)
                {
                    adjPosition = Graphics.Graphics.Camera.Position + (adjPosition - Graphics.Graphics.Camera.Position) * zoomFactor;
                }
            }
            else if (IsStickToZoomState)
            {
                adjPosition = Graphics.Graphics.Camera.Position + (adjPosition - Graphics.Graphics.Camera.Position) * zoomFactor;
            }


            WasRefreshedFlag = false;
        }


        public virtual void Draw()
        {
            if (aManager != null)
            {
                aManager.DrawCurrent(adjPosition, Color, adjRotation, adjOrigin, adjScale, 0f);
            }

            if(Text != null)
            {
                Font.Draw(Text, adjPosition, 0f, adjOrigin, adjScale, Color);
            }
        }


        public virtual void Refresh() 
        {
            WasRefreshedFlag = true;
        }

        public virtual void DrawDebug()
        {
            
        }


        public virtual void Destroy()
        {

        }
    }
}
