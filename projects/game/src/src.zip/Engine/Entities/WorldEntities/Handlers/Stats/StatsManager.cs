﻿using System;
using System.Collections.Generic;

namespace Entities
{
    public class StatsManager
    {
        public ExperienceStats ExperienceStats;
        public BattleHitStatsSet BodyHitStatsSet;

        public EntityStat[] Stats;
        public EntityAbility[] Abilities;

        public StatsBattleHitSpendHandler StatsBattleHitSpendHandler;

        public List<StatEffect> CurrentStatEffects;

        
        public StatsManager()
        {
            CurrentStatEffects = new List<StatEffect>();
        }

        public void RefillAll()
        {
            foreach (EntityStat stat in Stats)
            {
                if(stat != null)
                {
                    stat.Refill();
                }
            }
        }

        public EntityStat GetStat(EntityStats statType)
        {
            foreach (EntityStat stat in Stats)
            {
                if(stat.Type == statType)
                {
                    return stat;
                }
            }

            return null;
        }

        public void SpendStatsForBattleHit(BattleEntity ent)
        {
            StatsBattleHitSpendHandler.SpendStatsForBattleHit(GetStat(EntityStats.STAMINA), GetStat(EntityStats.MANA), ent);
        }

        public void ReceiveHPDamage(float amount)
        {
            GetStat(EntityStats.HP).ModifyCurrent(amount);
        }

        public void ReceivePoiseDamage(float amount)
        {
            GetStat(EntityStats.POISE).ModifyCurrent(amount);
        }


        public void UpdateAbilities(Resources.Model model)
        {
            foreach (EntityAbility feature in Abilities)
            {
                if(feature != null)
                {
                    feature.Update(this, model);
                }
            }
        }

        public EntityAbility GetStatAbility(EntityStatFeatures type)
        {
            foreach (EntityAbility ability in Abilities)
            {
                if (ability.Type == type)
                {
                    return ability;
                }
            }

            return null;
        }

        public T GetStatAbility<T>() where T : EntityAbility
        {
            foreach (EntityAbility ability in Abilities)
            {
                if (ability is T typed)
                    return typed;
            }
            return null;
        }



        public bool HasStatEffect(StatEffects effect)
        {
            if (!StatEffect.StatEffectMap.TryGetValue(effect, out var effectInstance))
                return false;

            return CurrentStatEffects.Contains(effectInstance);
        }

        public void AddStatEffect(StatEffects effect)
        {
            CurrentStatEffects.Add(StatEffect.StatEffectMap[effect]);
        }

        public void RemoveStatEffect(StatEffects effect)
        {
            var effectInstance = StatEffect.StatEffectMap[effect];
            effectInstance.TryRestore(Stats);
            CurrentStatEffects.Remove(effectInstance);
        }

        public void UpdateStatEffects()
        {
            var toRemove = new List<StatEffects>();

            foreach (var effect in CurrentStatEffects)
            {
                effect.Update(Stats);

                if (effect.MaxDuration != -1f && effect.CurrentDuration == 0f)
                {
                    toRemove.Add(effect.Type);
                }
            }

            foreach (var effectType in toRemove)
            {
                RemoveStatEffect(effectType);
            }
        }


        public bool CheckEnoughFinalBattleStamina(BattleEntity ent)
        {
            return GetStat(EntityStats.STAMINA).CurrentValue - BattleStatsCalculator.GetFinalStaminaPerHitCostForBattleEntity(ent) > 0;
        }

        public bool CheckEnoughFinalBattleMana(BattleEntity ent)
        {
            return GetStat(EntityStats.MANA).CurrentValue - BattleStatsCalculator.GetFinalManaPerHitCostForBattleEntity(ent) > 0;
        }

        public bool CheckEnoughStaminaForStat(EntityStats stat)
        {
            return GetStat(EntityStats.STAMINA).CurrentValue - GetStat(stat).StaminaDependencySec / (float)Graphics.Graphics.UpdatesPerSecond > 0;
        }

        public bool LostPoise()
        {
            return GetStat(EntityStats.POISE).LessEquealZero();
        }

        public bool CheckDead()
        {
            return GetStat(EntityStats.HP).LessEquealZero();
        }
    }
}
