﻿using Graphics;
using Microsoft.Xna.Framework;
using Physics;
using SharpDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class EntityMapManager
    {

        public EntityMap[] maps;
        public int CurrentMapId;
        public int MapsCount;

        public GlobalMapTime GlobalMapTime;

        public EntityMapManager()
        {
            MapsCount = 2;
            GlobalMapTime = new GlobalMapTime();
        }

        public void Init()
        {
            maps = new EntityMap[MapsCount];

            for (int i = 0; i < MapsCount; i++)
            {
                maps[i] = new EntityMap(i);
                maps[i].Entities = EntityMapSetter.FillEntityMap(i);
                maps[i].Events = EventMapSetter.FillEventMap(i);
                maps[i].FilterLayers = FilterLayerMapSetter.FillFilterLayerMap(i);
            }
        }

        public void Update()
        {
            GlobalMapTime.Update();
        }

        public void LoadMap(int nextId, Vector2 playerPos)
        {
            if(Entities.Player == null)
            {
                Entities.Player = new Player();
            }
            else
            {
                Entities.EntityManager.RemoveEntity(Entities.Player);
            }

            CurrentMapId = nextId;
            Entities.Player.Model.Body.MoveTo(PhysicalConverter.ToPhysicalVector(playerPos));
            maps[nextId].Entities.Add(Entities.Player);

            Physics.Physics.flatWorld.RefreshList(maps[nextId].Entities);

            Graphics.Graphics.BackgroundManager.RemoveAll();
            Graphics.Graphics.BackgroundManager.Init();

            Graphics.Graphics.LightManager.Init();
            Graphics.Graphics.FilterManager.UpdateLayers();
        }

        public void LoadInitialMap()
        {
            LoadMap(0, new Vector2(0, 1000));
        }


        public EntityMap GetCurrentMap()
        {
            return maps[CurrentMapId];
        }

    }
}
